Snipping Tool from Windows 10 RTM, but it supports Windows versions as old as Windows 7.

Basically the Snipping Tool from Windows Vista to Windows 8.1, but with the delay function present on later versions of Windows 10.

Originally made by @vxiiduu from GitHub. (original repo: https://github.com/vxiiduu/SnippingToolEx)